<?php
	$db = mysqli_connect('localhost','root','','easyshoot');
	if($db->connect_error)
	{
		die("Coudn't connect to database");
	}
	$sender = stripslashes(htmlspecialchars($_GET['sender']));
	$receiver = stripslashes(htmlspecialchars($_GET['receiver']));
	$message = stripslashes(htmlspecialchars($_GET['message']));
	if($sender == "" || $receiver == "" || $message == "")
		die();
	$result =$db->prepare("INSERT INTO messages VALUES(0,?,?,?)");
	$result->bind_param("sss", $sender, $receiver, $message);
	$result->execute();
	$result1 = mysqli_query($db,"INSERT INTO notifications (`id`, `note`, `username`, `viewed`) VALUES(0,'You Have Got A New Message From $sender', '$receiver', 'no')");
?>
