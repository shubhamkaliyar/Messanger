<?php
	$db = mysqli_connect('localhost','root','','easyshoot');
	if($db->connect_error)
	{
		die("Coudn't connect to database");
	}
	$sender = stripslashes(htmlspecialchars($_GET['sender']));
	$receiver = stripslashes(htmlspecialchars($_GET['receiver']));
	$result = mysqli_query($db,"SELECT * FROM messages WHERE sender= '$sender' && receiver= '$receiver'||sender= '$receiver' && receiver= '$sender'");
	while($r = mysqli_fetch_assoc($result))
	{
		echo $r['sender']."\\".$r['receiver']."\\".$r['message']."\n";
	}
?>
